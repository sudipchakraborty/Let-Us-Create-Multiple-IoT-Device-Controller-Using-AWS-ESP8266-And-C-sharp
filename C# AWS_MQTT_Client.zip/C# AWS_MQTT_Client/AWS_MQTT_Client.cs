﻿using System.Security.Cryptography.X509Certificates;
using System.Text;
using M2Mqtt;
using M2Mqtt.Messages;
using Newtonsoft.Json;
//////////////////////////////////////////////////////////////////////////////////
//From Nuget package manager add the below packages to run the MQTT module
//    a.	Newtonsoft.Json                     (by James Newton-King) 
//    b.	M2MqttClientDotnetcore              (by M2MqttClientDotnetCore1.0.1)
//////////////////////////////////////////////////////////////////////////////////
namespace Tools
{
    public class AWS_MQTT_Client
    {
        public string iotEndpoint;
        public string topic;
       
        int brokerPort = 8883;
        public string Received_Message = "";
        public bool connected = false;
        public bool subscribed=false;
        public bool received=false;
        MqttClient client;
        public string value="";
        string jsonState;
        public int test_val = 0;
        public string password;

        public AWS_MQTT_Client(string end_point,string topic,string password)
        {
            iotEndpoint=end_point;
            this.topic=topic;
            this.password=password;
        }

        public void connect()
        {
            try
            {
                string path = Path.Combine(System.IO.Directory.GetCurrent‌​Directory(), "AmazonRootCA1.pem"); 
                var caCert = X509Certificate.CreateFromCertFile(path);
                path = Path.Combine(System.IO.Directory.GetCurrent‌​Directory(), "device_certificate.cert.pfx");
                var clientCert = new X509Certificate2(path, password);

                client = new MqttClient(iotEndpoint, brokerPort, true, caCert, clientCert, MqttSslProtocols.TLSv1_2);

                client.MqttMsgSubscribed += IotClient_MqttMsgSubscribed;
                client.MqttMsgPublishReceived += IotClient_MqttMsgPublishReceived;

                string clientId = Guid.NewGuid().ToString();
                client.Connect(clientId);
                client.Subscribe(new string[] { topic }, new byte[] { MqttMsgBase.QOS_LEVEL_AT_LEAST_ONCE });
                connected= true;
            }
            catch(Exception ex)
            {
                connected = false;
                subscribed= false;
            }
        }

        private  void IotClient_MqttMsgPublishReceived(object sender, MqttMsgPublishEventArgs e)
        {
            Received_Message=Encoding.UTF8.GetString(e.Message);
            received=true;
          //  Console.WriteLine(Received_Message);
        }

        private  void IotClient_MqttMsgSubscribed(object sender, MqttMsgSubscribedEventArgs e)
        {
            subscribed= true;
        }

        public void send()
        {
            jsonState = "{\"state\":{\"desired\":{\"command\":\""+value+"\"}}}";

            if (connected)
            {
                byte[] Payload = Encoding.UTF8.GetBytes(jsonState);
                client.Publish(topic, Payload);
            }
        }

        public void send(string data)
        {
      
         //   jsonState = "{\"state\":{\"desired\":{\"command\":\""+data+"\"}}}";

            if (connected)
            {
                byte[] Payload = Encoding.UTF8.GetBytes(data);
                client.Publish(topic, Payload);
            }
        }

        public void test()
        {
            jsonState = "{\"state\":{\"desired\":{\"command\":\""+test_val.ToString()+"\"}}}";

            if (connected)
            {
                byte[] Payload = Encoding.UTF8.GetBytes(jsonState);
                client.Publish(topic, Payload);
                test_val++;
            }
        }

        public string Get_Data(string param="command")
        {
            dynamic jsonDe = JsonConvert.DeserializeObject(Received_Message);
            string s= jsonDe.state.desired[param].ToString();
            return s;
        }


















    }
}
