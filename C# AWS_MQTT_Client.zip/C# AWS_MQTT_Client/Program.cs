﻿using System.ComponentModel.Design;

using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using Tools;

internal class Program
{
    static AWS_MQTT_Client device;
    static int count = 0;
    static string place = "";

    private static void Main(string[] args)
    {
        string iotEndpoint = "";
     //   string topic = "$aws/things/MyThing/shadow/name/MyShadow/get/accepted";
        string topic = "";
        string password = "";
        device=new AWS_MQTT_Client(iotEndpoint, topic, password);

        if (!device.connected)
        {
            device.connect();
            Console.WriteLine("Device connected with AWS ok...");
        }

        while (device.connected)
        {
            Console.Write(DateTime.Now.ToString()+ ">");
            string input = Console.ReadLine();
            process_command(input);
        }
    }

    private static void process_command(string command)
    {
        if ((command=="list")||(command=="ls")) { Print_Device_List(); return; }
        var cmd = command.Split(' ');
        if ((cmd[0]=="open")||(cmd[0]=="set")) { place= cmd[1]; Console.WriteLine("place set:"+cmd[1]); return; }
        if ((cmd[0]=="close")||(cmd[0]=="stop")) { place= ""; Console.WriteLine("place reset:"+cmd[1]); return; }
        /////////////////////////////////////////////////////////////////////////
        if ((cmd[1]=="on") || (cmd[1]=="off")||(cmd[2]=="on") || (cmd[2]=="off")) power_state_update(cmd);
        else if ((cmd[1]=="speed")||(cmd[1]=="brightness") ||(cmd[1]=="colour")) Write_Analog(cmd);
        else if ((cmd[1]=="temp")||(cmd[1]=="humi")||(cmd[2]=="intensity")) Read_Analog(cmd);
        else if ((cmd[1]=="knob")||(cmd[1]=="door")) Read_Digital(cmd);
        else
        {
            Console.WriteLine("Request Handler not found for"+ cmd);
        }
    }

    private static void power_state_update(string[] cmd)
    {
        string pin = Get_PIN_number(cmd[0]);

        JObject jsonObject = new JObject(
            new JProperty("device_id", Get_Device_Id(place)),
                   new JProperty("pin", pin),
                   new JProperty("state", cmd[1])
        );
        string jsonString = jsonObject.ToString();
        device.send(jsonString);
    }

    private static void Write_Analog(string[] cmd)
    {
        //  device.send(str_tx+" "+state);
    }

    private static void Read_Analog(string[] cmd)
    {
        // device.send(str_tx+" "+state);
    }

    private static void Read_Digital(string[] cmd)
    {
        // device.send(str_tx+" "+state);
    }

    private static string Get_Device_Id(string room)
    {
        string id = "";

        switch (room)
        {
            case "bed_room":
                id= "1";
                break;
            /////////////
            case "kitchen":
                id="2";
                break;
            ///////////////
            case "dinning_space":
                id="3";
                break;
            /////////////
            case "bath_room":
                id="4";
                break;
            ////////////
            default:
                break;
        }
        return id;
    }

    private static string Get_PIN_number(string load_name)
    {
        if (place=="bed_room")
        {
            if (load_name=="tv")    return "D0";
            if (load_name=="fan")   return "D1";
            if (load_name=="bulb")  return "D2";
            if (load_name=="night") return "D3";
            if (load_name=="ac")    return "D4";
            if (load_name=="temp")  return "AI0";
            if (load_name=="humi")  return "AI1";
        }
        return "NA";
    }

    private static void Print_Device_List()
    {
        String lst = "The available Places are:\n";
                lst+="________________________\n";
        lst+="bed_room>tv,fan,bulb,night(lamp), ac, temp(erature), humi(dity)\n";
        lst+="kitchen>bulb,micro wave,mixer(grinder),exhaust fan,knob(gas)\n";
        lst+="dinning_space>tv,light,fan,plug,washing machine,light(get),door(get)\n";
        lst+="bath_room>Geyser,Exhaust fan,bulb,plug,door(get)\n";
        lst +="<End of List>\n";
        Console.WriteLine(lst);
    }


}// class